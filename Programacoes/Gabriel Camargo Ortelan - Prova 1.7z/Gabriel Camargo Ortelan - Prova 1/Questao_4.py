print ("Vou informar se um número inteiro é positivo, negativo ou igual a zero")
num = int(input("Digite um número: "))
if num == 0:
    print ("Seu número é o zero")
elif num >0:
    print ("Seu número é positivo")
elif num<0:
    print ("Seu número é negativo")
