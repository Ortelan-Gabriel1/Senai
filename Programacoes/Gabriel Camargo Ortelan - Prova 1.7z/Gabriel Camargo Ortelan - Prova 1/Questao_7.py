def area_retangulo (altura, base):
    return (base*altura)
print ("Vou calcular a área de um retângulo")
altura = float(input("Digite a altura do retângulo: "))
base = float(input("Digite a base do retângulo: "))

print (area_retangulo(base,altura))
