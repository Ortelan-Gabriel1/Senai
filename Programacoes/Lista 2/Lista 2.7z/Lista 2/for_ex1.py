print("Vou todos os números de 1 a 50 e depois essa mesma lista invertida")
for v in range(1, 51):
    print (v)
for i in range (50,0,-1):
    print (i)