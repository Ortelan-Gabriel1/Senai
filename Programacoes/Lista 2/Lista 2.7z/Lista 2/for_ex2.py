print ("Vou calcular os primeiros 50 números pares")
soma=0
for i in range(0,101,2):
    soma += i
print (f"A soma dos primeiros 50 números pares é {soma}")